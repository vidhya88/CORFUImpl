package edu.cornell.cs.weijia.bs;

import edu.cornell.cs.weijia.bs.PageMemBlock.GC_TYPE;

public abstract class MemBlock implements Snapshottable {

  public final static int BLOCK_SIZE = 0x4000000;
  
  /**
   * Constructor
   */
  public MemBlock() {
  }

  public abstract void read(int offset, int length, byte[]buf)throws BlockSnapshotException;
  public abstract void write(int offset, int length, byte[]buf)throws BlockSnapshotException;
  public abstract int getCurLen()throws BlockSnapshotException;
  public abstract int getBlockSize();
  
  /**
   * @author sonic
   * COW: Copy-On-Write
   * ROW: Redirect-On-Write
   */
  public enum BlockImplement{
	  JAVA_COW_HEAP,
	  PAGE_COW_HEAP,
	  PAGE_COW_APP,
	  PAGE_COW_JNI,
	  BASELINE,};
 
  /**
   * @param mm memory management 
   * @param sm snapshot mechanism
   * @return
   */
  static public MemBlock createMemBlock(BlockImplement bi){
    //by default we are using JavaHeapMemBlock
    MemBlock mb = null;
    switch(bi){
    case JAVA_COW_HEAP:
    	mb = new JhCOWMemBlockImpl();
    	break;
    case PAGE_COW_HEAP:
    	mb = new PageMemBlock(GC_TYPE.JAVA);
    	break;
    case PAGE_COW_APP:
    	mb = new PageMemBlock(GC_TYPE.APP);
    	break;
    case PAGE_COW_JNI:
    	mb = new PageMemBlock(GC_TYPE.JNI);
    	break;
    case BASELINE:
      mb = new BaselineBlock();
      break;
    default:
    	break;
    }
    return mb;
  }
}
